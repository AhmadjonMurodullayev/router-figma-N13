import React from 'react'
import Header from './layout/header/header'
import { Hero } from './components/hero/hero'
import datas from './data/data'
function App() {
  return (
    <div>
      <Header/>
      <Hero data={datas.hero}/>
    </div>
  )
}

export default App